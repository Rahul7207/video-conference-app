const express = require('express');
const http = require('http');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const { Server } = require('ws'); // WebSocket Server
const nodemailer = require('nodemailer'); // For sending emails

const app = express();
const server = http.createServer(app);
const wss = new Server({ server });

app.use(express.json());
app.use(express.static('public')); // Serve static files like HTML, CSS, JS

// MySQL connection setup
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'mydb',
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err);
  } else {
    console.log('Connected to the database');
  }
});

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  },
});
const upload = multer({ storage: storage });

// Registration route
app.post('/register', (req, res) => {
  const { username, email, password } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);

  const checkQuery = 'SELECT * FROM users WHERE email = ?';
  db.query(checkQuery, [email], (err, results) => {
    if (err) {
      console.error('Error checking email:', err);
      return res.status(500).json({ message: 'Error checking email' });
    }

    if (results.length > 0) {
      return res.status(400).json({ message: 'Email is already registered' });
    }

    const insertQuery = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
    db.query(insertQuery, [username, email, hashedPassword], (err) => {
      if (err) {
        console.error('Error inserting user into database:', err);
        return res.status(500).json({ message: 'Error registering user' });
      }
      return res.status(200).json({ message: 'User registered successfully' });
    });
  });
});

// User Login
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  const query = 'SELECT * FROM users WHERE email = ?';
  db.query(query, [email], (err, results) => {
    if (err) {
      return res.status(500).send({ error: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(400).send({ error: 'User not found' });
    }

    const user = results[0];
    if (bcrypt.compareSync(password, user.password)) {
      const token = jwt.sign({ userId: user.id }, 'your-secret-key', { expiresIn: '1h' });
      return res.json({ token, name: user.username, email: user.email });
    } else {
      return res.status(400).send({ error: 'Invalid credentials' });
    }
  });
});

// Protected Dashboard Route
app.get('/dashboard', (req, res) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(403).send('No token provided');
  }

  jwt.verify(token, 'your-secret-key', (err, decoded) => {
    if (err) {
      return res.status(403).send('Invalid token');
    }
    res.json({ message: 'Welcome to your dashboard!', user: decoded });
  });
});

// Create Meeting Route (GET)
app.get('/create-meeting', (req, res) => {
  const meetingId = uuidv4(); // Unique ID generation
  db.query('INSERT INTO meetings (meeting_id) VALUES (?)', [meetingId], (err, result) => {
    if (err) {
      console.error('Error creating meeting:', err);
      return res.status(500).send('Error creating meeting');
    }
    // Redirect to meeting-room.html with meetingId as query param
    res.redirect(`/meeting-room.html?meetingId=${meetingId}`);
  });
});


// -------------------------
// WebSocket Signaling Server
// -------------------------
const rooms = {}; // Track active rooms and connections

wss.on('connection', (ws) => {
  console.log('New WebSocket connection established.');

  ws.on('message', (message) => {
    const data = JSON.parse(message);
    const { type, meetingId, userId } = data;

    switch (type) {
      case 'join-room':
        if (!rooms[meetingId]) rooms[meetingId] = [];
        rooms[meetingId].push({ ws, userId });

        // Notify existing participants about the new participant
        rooms[meetingId].forEach(({ ws: client, userId: uid }) => {
          if (client !== ws) {
            client.send(JSON.stringify({ type: 'new-participant', userId }));
          }
        });
        break;

      case 'offer':
      case 'answer':
      case 'candidate':
        const participants = rooms[meetingId] || [];
        participants.forEach(({ ws: client }) => {
          if (client !== ws) {
            client.send(JSON.stringify(data));
          }
        });
        break;

      default:
        console.error(`Unhandled WebSocket message type: ${type}`);
    }
  });

  ws.on('close', () => {
    console.log('WebSocket connection closed.');

    // Remove user from rooms
    for (const meetingId in rooms) {
      rooms[meetingId] = rooms[meetingId].filter(({ ws: client }) => client !== ws);
      if (rooms[meetingId].length === 0) {
        delete rooms[meetingId];
      }
    }
  });
});

// Create Meeting Route with Email Notification (POST)
app.post('/create-meeting', upload.none(), (req, res) => {
  const { participantEmails, hostEmail } = req.body; // Include hostEmail
  const meetingId = uuidv4();
  const meetingLink = `http://localhost:3000/meeting-room.html?meetingId=${meetingId}`;

  // Check if host exists
  const checkUserQuery = 'SELECT * FROM users WHERE email = ?';
  db.query(checkUserQuery, [hostEmail], (err, results) => {
    if (err) {
      console.error('Error checking host email:', err);
      return res.status(500).json({ message: 'Error validating host email' });
    }
    if (results.length === 0) {
      return res.status(400).json({ message: 'Host email is not registered' });
    }

    // Save meeting
    const insertMeetingQuery = 'INSERT INTO meetings (meeting_id, host_email) VALUES (?, ?)';
    db.query(insertMeetingQuery, [meetingId, hostEmail], (err) => {
      if (err) {
        console.error('Error saving meeting:', err);
        return res.status(500).json({ message: 'Error creating meeting' });
      }

      // Send Emails
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'your-email@gmail.com',
          pass: 'your-email-password',
        },
      });

      const mailOptions = {
        from: 'your-email@gmail.com',
        to: participantEmails,
        subject: 'Invitation to Join Meeting',
        text: `You are invited to a meeting. Click to join: ${meetingLink}`,
      };

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error('Error sending email:', error);
          return res.status(500).json({ message: 'Error sending invitations' });
        }
        console.log('Email sent:', info.response);
        return res.json({ message: 'Meeting created', meetingLink });
      });
    });
  });
});

// Start Server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

